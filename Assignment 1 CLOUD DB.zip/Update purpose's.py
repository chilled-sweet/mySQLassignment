import pymysql

con = pymysql.connect(host='bxzrczih7bjg4hnslg2h-mysql.services.clever-cloud.com',
                      user='ub8lwxqpet8leowz', password='zQV33wXXXBcunCM3fXiq', database='bxzrczih7bjg4hnslg2h')
curs = con.cursor()

mn = str(input("\nEnter Model Name : "))
print('-'*40)

curs.execute(
    "select modelnm,price,purpose from mobile where modelnm ='%s' ORDER BY price" % mn)
data = curs.fetchall()

if data:
    for row in data:
        data = curs.fetchall()
        print("Model Name      : ", row[0])
        print("Price           : ", row[1])
        print("Current Purpose : ", row[2])
        print(" ")
        
    prn=str(input("Enter New Purpose of this Model : ")) 
    
#update mobile purpose
    curs.execute("update mobile set purpose = '%s' where modelnm='%s'" % (prn, mn))
    con.commit()
    print("\nPurpose's are Updated Successfully")
else:
    print("\nmobile does not exist..")

con.close()
