import pymysql

con = pymysql.connect(host='bxzrczih7bjg4hnslg2h-mysql.services.clever-cloud.com',
                      user='ub8lwxqpet8leowz', password='zQV33wXXXBcunCM3fXiq', database='bxzrczih7bjg4hnslg2h')
curs = con.cursor()

curs.execute("select * from mobile")
data = curs.fetchall()

#All mobile data is returned in the form of tuple of tuples

print(data)
con.close()
