import pymysql

con = pymysql.connect(host='bxzrczih7bjg4hnslg2h-mysql.services.clever-cloud.com',
                      user='ub8lwxqpet8leowz', password='zQV33wXXXBcunCM3fXiq', database='bxzrczih7bjg4hnslg2h')
curs = con.cursor()

#Add new column
curs.execute("ALTER TABLE mobile ADD purpose VARCHAR(50)")
con.commit()
print("\nNew column inserted..\n")
con.close()
