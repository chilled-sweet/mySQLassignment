import pymysql

con = pymysql.connect(host='bxzrczih7bjg4hnslg2h-mysql.services.clever-cloud.com',
                      user='ub8lwxqpet8leowz', password='zQV33wXXXBcunCM3fXiq', database='bxzrczih7bjg4hnslg2h')
curs = con.cursor()

cm = str(input('\nEnter Company Name : '))
print('-'*40)

#select * from company where model name='Samsung...'

curs.execute("select modelnm,price from mobile where company='%s' ORDER BY price" % cm)
data = curs.fetchall()

try:
    for row in data:
        data = curs.fetchall()
        print("Model Name : ", row[0])
        print("Price      : ", row[1])
        print(" ")
except:
    print('     Sorry....\nMobile Not found')

con.close()
