import pymysql

con = pymysql.connect(host='bxzrczih7bjg4hnslg2h-mysql.services.clever-cloud.com',
                      user='ub8lwxqpet8leowz', password='zQV33wXXXBcunCM3fXiq', database='bxzrczih7bjg4hnslg2h')
curs = con.cursor()

rm = input("\nEnter RAM size : ")
ro = input("\nEnter ROM size : ")

#select * from mobile ..

curs.execute("select * from mobile where ram ='%s' AND rom = '%s'" %(rm,ro))
data = curs.fetchall()

if pymysql:
    print("\nMobiles with RAM: '%s' and \nMobiles with ROM: '%s' are following :" % (rm, ro))
    print('-'*40)
    try:
        for index, i in enumerate(data,1):
            data = curs.fetchall()
            print(index,':',i[2],i[1])
    except:
        print("               \nSorry....\nNo mobiles found with the specified RAM-ROM combination.")
print('-'*40)

con.close()
