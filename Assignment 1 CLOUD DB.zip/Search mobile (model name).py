import pymysql

con = pymysql.connect(host='bxzrczih7bjg4hnslg2h-mysql.services.clever-cloud.com',
                      user='ub8lwxqpet8leowz', password='zQV33wXXXBcunCM3fXiq', database='bxzrczih7bjg4hnslg2h')
curs = con.cursor()

mn = str(input('\nEnter Model Name : '))
print('-'*40) 

#select * from mobile where model name='Galaxy...'

curs.execute("select * from mobile where modelnm='%s'" % mn)
data = curs.fetchone()

#print(data)
try:
    print('Company Name :', data[2])
    print('Connectivity :', data[3])
    print('RAM          :', data[4])
    print('ROM          :', data[5])
    print('Color        :', data[6])
    print('Screen       :', data[7])
    print('Battery      :', data[8])
    print('Processor    :', data[9])
    print('Price        :', data[10])
    print('Rating       :', data[11])
except:
    print('     Sorry....\nMobile Not found')

con.close()
