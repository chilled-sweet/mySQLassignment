import pymysql

con = pymysql.connect(host='bxzrczih7bjg4hnslg2h-mysql.services.clever-cloud.com',
                      user='ub8lwxqpet8leowz', password='zQV33wXXXBcunCM3fXiq', database='bxzrczih7bjg4hnslg2h')
curs = con.cursor()

id = int(input("\nEnter Product id    : "))
mn = input('Enter Model Name          : ')
cn = input("Enter Company Name        : ")
cv = input("Enter Connectivity(4G\5G) : ")
rm = input("Enter RAM                 : ")
ro = input("Enter ROM                 : ")
co = input("Enter Color               : ")
sc = input("Enter Screen              : ")
bt = input("Enter Battery             : ")
pro = input("Enter Processor          : ")
pri = float(input("Enter price        : "))
rt = float(input("Enter Rating        : "))
pr = input("Enter the Purpose         : ")

curs.execute("insert into mobile value(%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s',%.2f,%.2f,'%s')" 
             %(id,mn,cn,cv,rm,ro,co,sc,bt,pro,pri,rt,pr))
con.commit()
print("\nNew Mobile Data added successfully\n")
con.close()
