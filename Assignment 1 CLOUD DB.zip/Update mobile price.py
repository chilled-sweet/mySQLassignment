import pymysql

con = pymysql.connect(host='bxzrczih7bjg4hnslg2h-mysql.services.clever-cloud.com',
                      user='ub8lwxqpet8leowz', password='zQV33wXXXBcunCM3fXiq', database='bxzrczih7bjg4hnslg2h')
curs = con.cursor()

id = int(input("\nEnter Product id : \n"))
print('-'*40)

#select * from mobile where Product id='01..'
curs.execute("select * from mobile where prodid=%d" %id)
data = curs.fetchone()

if data:
    #print(data)
    print('Product id   : ', data[0])
    print('Company      : ', data[2])
    print('Model        : ', data[1])
    print('Price        : ', data[10])
    print('-'*40)
    
    pr=float(input("\nEnter new Price of Mobile : "))
    
    #update mobile salary
    curs.execute("update mobile set price = %.2f where prodid=%d" %(pr,id))
    con.commit()
    print("\nPrice Update Successfully")
else:
    print("\nmobile does not exist..")

con.close()
