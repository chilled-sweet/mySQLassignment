import pymysql

con = pymysql.connect(host='bxzrczih7bjg4hnslg2h-mysql.services.clever-cloud.com',
                      user='ub8lwxqpet8leowz', password='zQV33wXXXBcunCM3fXiq', database='bxzrczih7bjg4hnslg2h')
curs = con.cursor()

ro = str(input('\nEnter ROM of Mobile : '))
print('-'*40)

#select * from mobile'

curs.execute(
    "select modelnm,price,rom from mobile where rom='%s' ORDER BY rom DESC" % ro)
data = curs.fetchall()

try:
    for row in data:
        data = curs.fetchall()
        print("Model Name : ", row[0])
        print("Price      : ", row[1])
        print("ROM        : ", row[2])
        print(" ")
except:
    print('     Sorry....\nMobile Not found')

con.close()
